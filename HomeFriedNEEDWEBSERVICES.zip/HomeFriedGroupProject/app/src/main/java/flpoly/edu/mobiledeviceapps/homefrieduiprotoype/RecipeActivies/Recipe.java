package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies;

public class Recipe {

    public String RecipeURL;
    public String RecipeNote;
    public boolean isChecked;

    public Recipe(String RecipeURL)
    {
        this.RecipeURL = RecipeURL;
        this.RecipeNote = null;
        this.isChecked = false;
    }

    //Check if recipe is checked or not
    public boolean isRecipeChecked()
    {
        if(this.isChecked)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
