package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities;

public class Search {
    public String URL;
    public boolean isChecked;

    public Search(String URL)
    {
        this.URL = URL;
    }

    //Check if recipe is checked or not
    public boolean isURLChecked()
    {
        if(this.isChecked)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
