package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities;



import static android.widget.Toast.LENGTH_SHORT;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import androidx.browser.customtabs.CustomTabsIntent;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;


public class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.ViewHolder> {


    //Variables handy for updating data
    static public List<Ingredient> ingredientsList;
    CheckBox checkIngredient;



    //Data is passed in to the constructor for adapter class from the Ingredient model class
    public IngredientAdapter(List<Ingredient> ingredientsList) {
        this.ingredientsList = ingredientsList;

    }

    //retrieve the List
    public static List<Ingredient> getIngredientList()
    {
        return ingredientsList;
    }

    //retrieve the ingredient at a specific index
    public static Ingredient getIngredient(int i)
    {
        return ingredientsList.get(i);
    }


    @Override
    public int getItemCount() {
        if (ingredientsList != null) {
            return ingredientsList.size();
        } else {
            return 0;
        }
    }


    //inflates the row layout from the xml cardview
    @Override
    public IngredientAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.ingredient_view, parent, false);


        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull IngredientAdapter.ViewHolder holder, int position) {
        //holder.name.setText(nameTxt);
        //holder.name.setText((CharSequence) this.ingredientsList.get(position));
        checkIngredient = holder.checkBox;
        checkIngredient.setOnClickListener(v -> {
            if (ingredientsList.get(position).isChecked == true) {
                ingredientsList.get(position).isChecked = false;
                Toast.makeText(checkIngredient.getContext(), "Remove " + ingredientsList.get(position).ingredientName, Toast.LENGTH_SHORT).show();
            }
            if (ingredientsList.get(position).isChecked == false) {
                ingredientsList.get(position).isChecked = true;
                Toast.makeText(checkIngredient.getContext(), "Add " + ingredientsList.get(position).ingredientName, Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Create viewholder class for recipe recyclerview
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public View view;
        //public TextView name;
        public final CheckBox checkBox;
        public static int listIndex = 0; //index for taking Ingredients from the List of Ingredients

         public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            this.view = view;

            this.checkBox = view.findViewById(R.id.CheckIngredient);

            //set text for each individual checkbox
            Ingredient ingredi = IngredientAdapter.getIngredient(listIndex);
            checkBox.setText(ingredi.ingredientName);

             //move to next index
             listIndex++;
             };

        @Override
        public void onClick(View view) {
            //Toast.makeText(view.getContext(), "Ingredient Checked", Toast.LENGTH_SHORT).show();
        }

    }

}

