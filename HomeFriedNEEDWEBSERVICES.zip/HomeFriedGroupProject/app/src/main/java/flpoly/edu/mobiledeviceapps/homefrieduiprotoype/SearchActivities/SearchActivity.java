package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.Ingredient;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.IngredientAdapter;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies.RecipeAdapter;

public class SearchActivity extends AppCompatActivity {

    ImageButton SearchByKeyword;
    ImageButton SaveRecipe;
    TextInputEditText KeywordInput;
    TextView viewURL;

    //Create list for URLs
    public List<Search> URLList = new ArrayList<>();
    public List<Ingredient> filterList; //save passed intent list to filterList
    public List<String> filterNames = new ArrayList<>(); //List to hold checked ingredient names

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        //receive intent from pantryactivity
        //Intent intent = getIntent();
        filterList = (List<Ingredient>) getIntent().getSerializableExtra("List");

        if(filterList != null) {


            //add only the names of the checked true ingredients
            for (Ingredient i : filterList)
            {
                if(i.isChecked == true)
                {
                    filterNames.add(i.ingredientName);
                    Log.v("Adding Ingredient to Search: ", i.ingredientName);
                }
            }
        }
/*
        //receive intent from pantryactivity
        Intent intent = getIntent();
        //Bundle args = intent.getBundleExtra("List");
        Bundle args = intent.getExtras();

        if(args != null) {
            //filterList = (List<Ingredient>) args.getSerializable("LIST");
            filterList = (List<Ingredient>) args.getSerializable("LIST");

        //add only the names of the checked true ingredients
        for (Ingredient i : filterList)
        {
            if(i.isChecked == true)
            {
                filterNames.add(i.ingredientName);
                Log.v("Adding Ingredient to Search: ", i.ingredientName);
            }
        }

 */

        //Link object to recyclerview in layout
        RecyclerView viewWeb = findViewById(R.id.SearchRecipe);
        //Link Activity TextView to recyclerview TextView
        this.viewURL = findViewById(R.id.CheckURL);

        //set the adapter
        viewWeb.setLayoutManager(new LinearLayoutManager(this));
        //viewWebSites.setAdapter(new SearchAdapter(URLList));
        viewWeb.setAdapter(new SearchAdapter(filterNames));

        //Test the recycler view
        for(int i = 0; i < 20; i++) {
            addSearchInfo("URL");
        }


        //set SearchByKeyword to button
        SearchByKeyword = findViewById(R.id.SearchByKeyword);

        SearchByKeyword.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Search using the keyword entered in Textbox", LENGTH_SHORT).show();

        });


        //set SaveRecipe to button
        SaveRecipe = findViewById(R.id.SaveRecipe);

        SaveRecipe.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Saves recipe to your recipe list", LENGTH_SHORT).show();

        });


        //set Keyword input to the Text Input
        KeywordInput = findViewById(R.id.KeywordInput);


    }

    //Will add an ingredient to the Pantry List array
    public void addSearchInfo(String input)
    {
        URLList.add(new Search(input));
        filterNames.add(input);
    }
}
