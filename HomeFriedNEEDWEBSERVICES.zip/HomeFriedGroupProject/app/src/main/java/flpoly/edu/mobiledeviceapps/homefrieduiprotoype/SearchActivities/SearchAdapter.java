package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.Ingredient;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.IngredientAdapter;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies.RecipeAdapter;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities.Search;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {

    public List<Search> URLArrayList;
    static public List<String> filterNames = new ArrayList<>();
    TextView viewURL;


    //Data is passed in to the constructor for adapter class from the Ingredient model class
    public SearchAdapter(List<String> filterNames)
    {
        this.filterNames = filterNames;
    }


    //retrieve the List
    public static List<String> getFilterList()
    {
        return filterNames;
    }

    //retrieve the ingredient at a specific index
    public static String getFilter(int i)
    {
        return filterNames.get(i);
    }


    @Override
    public int getItemCount() {
        if (filterNames != null) {
            return filterNames.size();
        } else {
            return 0;
        }
    }


    //inflates the row layout from the xml cardview
    @Override
    public SearchAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_view, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchAdapter.ViewHolder holder, int position) {
        ///////////////////////////////////////

        //PLACE WEBSERVICES ACTIONS IN HERE

        //////////////////////////////////////
        holder.URLview.setText("Can place URL in here");
    }



    //@Override
 //   public void onBindViewHolder(@NonNull IngredientAdapter.ViewHolder holder, int position) {
        // String nameTxt = ingredientsList.get(position).ingredientName;
        // holder.name.setText(nameTxt);
        //holder.name.setText((CharSequence) this.URLArrayList.get(position));
  //  }

    //Create viewholder class for recipe recyclerview
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public View view;
        public TextView URLview;
        public static int listindex = 0;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            this.view = view;

            this.URLview = view.findViewById(R.id.CheckURL);

            //CAN PLACE SET TEXT ACTIONS HERE IF NEEDED
            if(listindex < SearchAdapter.filterNames.size())
            {
                String name = SearchAdapter.getFilter(listindex);
                URLview.setText(name);
                listindex++;
            }

        }

        @Override
        public void onClick(View view) {
            //Toast.makeText(view.getContext(), "Recipe Checked", Toast.LENGTH_SHORT).show();
        }
    }

}
