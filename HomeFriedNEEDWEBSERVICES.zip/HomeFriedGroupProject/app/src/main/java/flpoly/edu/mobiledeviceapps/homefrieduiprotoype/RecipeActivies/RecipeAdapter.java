package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.IngredientAdapter;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies.Recipe;

public class RecipeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public List<Recipe> RecipeList;


    //Data is passed in to the constructor for adapter class from the Ingredient model class
    public RecipeAdapter(List<Recipe> RecipeList) {
        this.RecipeList = RecipeList;
    }


    @Override
    public int getItemCount() {
        if (RecipeList != null) {
            return RecipeList.size();
        } else {
            return 0;
        }
    }


    //inflates the row layout from the xml cardview
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_view, parent, false);

        return new ViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }


    //@Override
    public void onBindViewHolder(@NonNull IngredientAdapter.ViewHolder holder, int position) {
        // String nameTxt = ingredientsList.get(position).ingredientName;
        // holder.name.setText(nameTxt);
        //holder.name.setText((CharSequence) this.RecipeList.get(position));
    }

    //Create viewholder class for recipe recyclerview
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public View view;
        public TextView name;
        //public final CheckBox checkBox;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            this.view = view;
            this.name = view.findViewById(R.id.CheckRecipe);
        }

        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(), "Recipe Checked", Toast.LENGTH_SHORT).show();
        }
    }

}
