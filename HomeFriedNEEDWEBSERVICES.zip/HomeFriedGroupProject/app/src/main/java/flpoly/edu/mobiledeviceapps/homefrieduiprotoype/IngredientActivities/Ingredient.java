package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities;

import android.widget.CheckBox;


public class Ingredient implements java.io.Serializable {

    public String ingredientName;  //ingredient name
    public String ingredientNote;  //ingredient note
    public boolean isChecked;      //if ingredient was selected by checkbox


    //Constructor for ingredient creation
    public Ingredient(String ingredientName)
    {
        this.ingredientName = ingredientName;
        this.ingredientNote = null;
        this.isChecked = false;
    }


    //Check if ingredient is checked or not
    public boolean isIngredientChecked()
    {
        if(this.isChecked)
        {
            return true;
        }
        else
        {
            return false;
        }
    }


}
