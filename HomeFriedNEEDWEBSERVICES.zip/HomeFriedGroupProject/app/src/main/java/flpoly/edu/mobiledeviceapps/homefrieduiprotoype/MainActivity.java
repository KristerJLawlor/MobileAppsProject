package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.Ingredient;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.IngredientAdapter;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities.PantryActivity;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies.RecipeActivity;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities.SearchActivity;

public class MainActivity extends AppCompatActivity {

    ImageButton YourPantry;
    ImageButton YourRecipes;
    ImageButton SearchRecipes;
    ImageButton About;

    //Create a shared preferences key to pass between activities
    public static final String SHAREDPREFS = "SHAREDPREFS";
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create a shared preferences key to pass between activities
        sharedPreferences = getSharedPreferences(SHAREDPREFS, Context.MODE_PRIVATE);
        //Create a shared preferences editor to edit the values
        SharedPreferences.Editor editor = sharedPreferences.edit();



        //set Your Pantry to the button
        YourPantry = findViewById(R.id.YourPantry);

        //set the on click listener to open the Ingredients activity
        YourPantry.setOnClickListener(v -> {

            Intent pantryActivity = new Intent(MainActivity.this, PantryActivity.class);
            startActivity(pantryActivity);

        });


        //set Your Recipes to the button
        YourRecipes = findViewById(R.id.YourRecipes);

        //set the on click listener to open the Recipes activity
        YourRecipes.setOnClickListener(v -> {

            Intent recipeActivity = new Intent(MainActivity.this, RecipeActivity.class);
            startActivity(recipeActivity);

        });


        //set Search Recipes to the button
        SearchRecipes = findViewById(R.id.SearchRecipes);

        //set the on click listener to open the Search activity
        SearchRecipes.setOnClickListener(v -> {

            Intent searchActivity = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(searchActivity);

        });


        //set About to the button
        About = findViewById(R.id.About);

        //set the on click listener to open the Ingredients activity
        About.setOnClickListener(v -> {

            Intent aboutActivity = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(aboutActivity);

        });


    }
}