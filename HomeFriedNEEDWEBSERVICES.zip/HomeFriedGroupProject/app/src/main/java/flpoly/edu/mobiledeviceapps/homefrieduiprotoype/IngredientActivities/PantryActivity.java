package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.IngredientActivities;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;
import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.SearchActivities.SearchActivity;

public class PantryActivity extends AppCompatActivity {

    ImageButton AddFilter;
    ImageButton AddNote;
    ImageButton AddIngredient;
    ImageButton DeleteIngredient;
    CheckBox checkIngredient;
    ConstraintLayout constraintLayout1;
    PopupWindow popupWindow;
    Button Save;


    //Create list for Ingredients
    public List<Ingredient> pantryList = new ArrayList<>();



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantry);



        addIngredientInfo("Strawberries");
        addIngredientInfo("Ground Beef");
        addIngredientInfo("Whole Milk");
        addIngredientInfo("Tomatoes");
        addIngredientInfo("Jalapenos");
        addIngredientInfo("Salmon");
        addIngredientInfo("Eggs");
        addIngredientInfo("Mayonnaise");
        addIngredientInfo("Butter");
        addIngredientInfo("Spinach");
        addIngredientInfo("Parmesan Cheese");

        //Link object to recyclerview in layout
        RecyclerView viewIngredients = findViewById(R.id.ViewPantry);
        //Link Checkbox to recyclerview checkbox
        checkIngredient = findViewById(R.id.CheckIngredient);

        //set the adapter
        viewIngredients.setLayoutManager(new LinearLayoutManager(this));
        viewIngredients.setAdapter(new IngredientAdapter(pantryList));
        //viewIngredients.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL));


        //check that the ingredients start as false
        for (Ingredient i : IngredientAdapter.ingredientsList) {
            Log.v("Check", String.valueOf(i.isChecked));
        }


        //set AddFilter as a button
        AddFilter = findViewById(R.id.AddFilter);
        //set on click listener
        //will add the checked ingredients to the search list
        AddFilter.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Add ingredient as a filter", LENGTH_SHORT).show();

            //Pass intent to search activity
            Intent intent = new Intent(this, SearchActivity.class);
            List<Ingredient> List = IngredientAdapter.ingredientsList;

         //   Bundle args = new Bundle();
         //   args.putSerializable("LIST", (Serializable) List);
            intent.putExtra("List", (Serializable) List);
            startActivity(intent);

        });

        //set AddNote as a button
        AddNote = findViewById(R.id.AddNote);
        constraintLayout1 = (ConstraintLayout)findViewById(R.id.PantryLayout);
        //set on click listener
        //Will popup a prompt to add a note to an ingredient
        AddNote.setOnClickListener(v -> {
                    //Toast.makeText(PantryActivity.this, "Remove ingredient from filter list", LENGTH_SHORT).show();
                    //instantiate the popup window
                    LayoutInflater layoutInflater = (LayoutInflater) PantryActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View customView = layoutInflater.inflate(R.layout.pantry_note_popup, null);

                    Save = (Button) customView.findViewById(R.id.closePopupBtn);

                    //instantiate popup window
                    popupWindow = new PopupWindow(customView, ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT, true);

                    //display the popup window
                    popupWindow.showAtLocation(constraintLayout1, Gravity.CENTER, 0, 0);

                    //close the popup window on button click
                    Save.setOnClickListener(x -> {

                            //Exit Popup window
                            popupWindow.dismiss();
                    });
                });

        //set AddIngredient as a button
        AddIngredient = findViewById(R.id.AddIngredient);
        //set on click listener
        //add an ingredient to the Pantry List
        AddIngredient.setOnClickListener(v -> {
            //Toast.makeText(PantryActivity.this, "Add ingredient to your pantry", LENGTH_SHORT).show();
            //instantiate the popup window
            LayoutInflater layoutInflater = (LayoutInflater) PantryActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View customView = layoutInflater.inflate(R.layout.pantry_note_popup, null);

            Save = customView.findViewById(R.id.closePopupBtn);

            //instantiate popup window
            popupWindow = new PopupWindow(customView, ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT, true);

            //display the popup window
            popupWindow.showAtLocation(constraintLayout1, Gravity.CENTER, 0, 0);

            //close the popup window on button click
            Save.setOnClickListener(x -> {

                //Exit Popup window
                popupWindow.dismiss();
            });
        });

        //set DeleteIngredient as a button
        DeleteIngredient = findViewById(R.id.DeleteIngredient);
        //set on click listener
        //delete all ingredients currently checked in the list
        DeleteIngredient.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Delete ingredient from your pantry", LENGTH_SHORT).show();
        });

    }

    //Will add an ingredient to the Pantry List array
    public void addIngredientInfo(String input)
    {
        pantryList.add(new Ingredient(input));
    }


    //Will set the note to the checked ingredient

}