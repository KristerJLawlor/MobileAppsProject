package flpoly.edu.mobiledeviceapps.homefrieduiprotoype.RecipeActivies;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import flpoly.edu.mobiledeviceapps.homefrieduiprotoype.R;

public class RecipeActivity extends AppCompatActivity {

    ImageButton Remove;
    ImageButton AddNote1;
    CheckBox checkRecipe;
    ConstraintLayout constraintLayout2;
    PopupWindow popupWindow1;
    Button Save1;

    //Create list for Recipes
    public List<Recipe> recipeList = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        //Link object to recyclerview in layout
        RecyclerView viewRecipe = findViewById(R.id.ViewRecipe);
        //Link Checkbox to recyclerview checkbox
        checkRecipe = findViewById(R.id.CheckRecipe);

        //set the adapter
        viewRecipe.setLayoutManager(new LinearLayoutManager(this));
        viewRecipe.setAdapter(new RecipeAdapter(recipeList));
        //viewIngredients.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        for(int i = 0; i < 20; i++) {
            addRecipeInfo("URL");
        }
        //set Remove to a button
        Remove = findViewById(R.id.RemoveRecipe);
        //set on click listener to Remove
        Remove.setOnClickListener(v -> {
            Toast.makeText(RecipeActivity.this, "Remove recipe from list", LENGTH_SHORT).show();

        });
        //set AddNote to a button
        AddNote1 = findViewById(R.id.AddRecipeNote);
        constraintLayout2 = (ConstraintLayout)findViewById(R.id.RecipeLayout);
        //set on click listener to AddNote
        AddNote1.setOnClickListener(v -> {
            //Toast.makeText(RecipeActivity.this, "Popup Text to enter notes", LENGTH_SHORT).show();
            //instantiate the popup window
            LayoutInflater layoutInflater1 = (LayoutInflater) RecipeActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View customView1 = layoutInflater1.inflate(R.layout.recipe_note_popup, null);

            Save1 = (Button) customView1.findViewById(R.id.closePopupBtn);

            //instantiate popup window
            popupWindow1 = new PopupWindow(customView1, ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT, false);

            //display the popup window
            popupWindow1.setFocusable(true);
            popupWindow1.update();
            popupWindow1.showAtLocation(constraintLayout2, Gravity.CENTER, 0, 0);
            //popupWindow1.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

            //close the popup window on button click
            Save1.setOnClickListener(x -> {

                //Exit Popup window
                popupWindow1.dismiss();
            });

        });

    }

    //Will add an ingredient to the Pantry List array
    public void addRecipeInfo(String input)
    {
        recipeList.add(new Recipe(input));
    }
}