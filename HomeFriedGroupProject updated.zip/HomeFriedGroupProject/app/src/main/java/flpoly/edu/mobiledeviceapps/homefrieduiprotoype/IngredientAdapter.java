package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;


import android.content.Context;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class IngredientAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public List<Ingredient> ingredientsList;



    //Data is passed in to the constructor for adapter class from the Ingredient model class
    public IngredientAdapter(List<Ingredient> ingredientsList) {
        this.ingredientsList = ingredientsList;
    }


    @Override
    public int getItemCount() {
        if (ingredientsList != null) {
            return ingredientsList.size();
        } else {
            return 0;
        }
    }


    //inflates the row layout from the xml cardview
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.ingredient_view, parent, false);

        return new ViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }


    //@Override
    public void onBindViewHolder(@NonNull IngredientAdapter.ViewHolder holder, int position) {
       // String nameTxt = ingredientsList.get(position).ingredientName;
        // holder.name.setText(nameTxt);
        holder.name.setText((CharSequence) this.ingredientsList.get(position));
    }

    //Create viewholder class for ingredient recyclerview
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public View view;
        public TextView name;
        //public final CheckBox checkBox;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            this.view = view;
            this.name = view.findViewById(R.id.CheckIngredient);
        }

        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(), "Ingredient Checked", Toast.LENGTH_SHORT).show();
        }
    }
    
}
