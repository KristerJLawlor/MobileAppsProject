package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PantryActivity extends AppCompatActivity {

    ImageButton AddFilter;
    ImageButton RemoveFilter;
    ImageButton AddIngredient;
    ImageButton DeleteIngredient;
    RecyclerView recyclerView;
    CheckBox check;


    //Create list for Ingredients
    public List<Ingredient> pantryList = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantry);

        //Link object to recyclerview in layout
        RecyclerView viewIngredients = findViewById(R.id.ViewPantry);

        //set the adapter
        viewIngredients.setLayoutManager(new LinearLayoutManager(this));
        viewIngredients.setAdapter(new IngredientAdapter(pantryList));
        //viewIngredients.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        for(int i = 0; i < 20; i++) {
            addIngredientInfo("Food");
        }


        //set AddFilter as a button
        AddFilter = findViewById(R.id.AddFilter);
        //set on click listener
        //will add the checked ingredients to the search list
        AddFilter.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Add ingredient as a filter", LENGTH_SHORT).show();
        });

        //set AddNote as a button
        RemoveFilter = findViewById(R.id.AddNote);
        //set on click listener
        //Will popup a prompt to add a note to an ingredient
        RemoveFilter.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Remove ingredient from filter list", LENGTH_SHORT).show();
        });

        //set AddIngredient as a button
        AddIngredient = findViewById(R.id.AddIngredient);
        //set on click listener
        //add an ingredient to the Pantry List
        AddIngredient.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Add ingredient to your pantry", LENGTH_SHORT).show();
        });

        //set DeleteIngredient as a button
        DeleteIngredient = findViewById(R.id.DeleteIngredient);
        //set on click listener
        //delete all ingredients currently checked in the list
        DeleteIngredient.setOnClickListener(v -> {
            Toast.makeText(PantryActivity.this, "Delete ingredient from your pantry", LENGTH_SHORT).show();
        });

    }

    //Will add an ingredient to the Pantry List array
    public void addIngredientInfo(String input)
    {
        pantryList.add(new Ingredient(input));
    }

}