package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class RecipeActivity extends AppCompatActivity {

    ImageButton Remove;
    ImageButton AddNote;
    RecyclerView recyclerView1;
    LinearLayoutManager linearLayoutManager1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        // get the reference of RecyclerView
        RecyclerView recyclerView1 = (RecyclerView) findViewById(R.id.ViewRecipe);
        // set a LinearLayoutManager with default orientation
        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(getApplicationContext());
        recyclerView1.setLayoutManager(linearLayoutManager1); // set LayoutManager to RecyclerView

        //set Remove to a button
        Remove = findViewById(R.id.Remove);
        //set on click listener to Remove
        Remove.setOnClickListener(v -> {
            Toast.makeText(RecipeActivity.this, "Remove recipe from list", LENGTH_SHORT).show();

        });
        //set AddNote to a button
        AddNote = findViewById(R.id.AddNote);
        //set on click listener to AddNote
        AddNote.setOnClickListener(v -> {
            Toast.makeText(RecipeActivity.this, "Popup Text to enter notes", LENGTH_SHORT).show();

        });

    }
}