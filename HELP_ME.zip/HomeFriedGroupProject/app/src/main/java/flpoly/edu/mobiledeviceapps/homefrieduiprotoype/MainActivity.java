package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ImageButton YourPantry;
    ImageButton YourRecipes;
    ImageButton SearchRecipes;
    ImageButton About;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //set Your Pantry to the button
        YourPantry = findViewById(R.id.YourPantry);

        //set the on click listener to open the Ingredients activity
        YourPantry.setOnClickListener(v -> {

            Intent pantryActivity = new Intent(MainActivity.this, PantryActivity.class);
            startActivity(pantryActivity);

        });


        //set Your Recipes to the button
        YourRecipes = findViewById(R.id.YourRecipes);

        //set the on click listener to open the Recipes activity
        YourRecipes.setOnClickListener(v -> {

            Intent recipeActivity = new Intent(MainActivity.this, RecipeActivity.class);
            startActivity(recipeActivity);

        });


        //set Search Recipes to the button
        SearchRecipes = findViewById(R.id.SearchRecipes);

        //set the on click listener to open the Search activity
        SearchRecipes.setOnClickListener(v -> {

            Intent searchActivity = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(searchActivity);

        });


        //set About to the button
        About = findViewById(R.id.About);

        //set the on click listener to open the Ingredients activity
        About.setOnClickListener(v -> {

            Intent aboutActivity = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(aboutActivity);

        });


    }
}