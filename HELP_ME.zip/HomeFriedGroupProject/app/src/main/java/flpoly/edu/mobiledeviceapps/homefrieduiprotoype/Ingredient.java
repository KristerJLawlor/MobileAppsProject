package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import android.widget.CheckBox;


public class Ingredient {

    public String ingredientName;
    public boolean isChecked;



    public Ingredient(String ingredientName)
    {
        this.ingredientName = ingredientName;
        this.isChecked = false;
    }


}
