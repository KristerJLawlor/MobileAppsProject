package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;


import com.google.android.material.textfield.TextInputEditText;

public class SearchActivity extends AppCompatActivity {

    ImageButton SearchByKeyword;
    ImageButton SaveRecipe;
    TextInputEditText KeywordInput;
    CheckBox SearchLocal;
    CheckBox SearchCategory;
    RecyclerView recyclerView2;
    LinearLayoutManager linearLayoutManager2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // get the reference of RecyclerView
        RecyclerView recyclerView2 = (RecyclerView) findViewById(R.id.SearchRecipe);
        // set a LinearLayoutManager with default orientation
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(getApplicationContext());
        recyclerView2.setLayoutManager(linearLayoutManager2); // set LayoutManager to RecyclerView

        //set SearchByKeyword to button
        SearchByKeyword = findViewById(R.id.SearchByKeyword);

        SearchByKeyword.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Search using the keyword entered in Textbox", LENGTH_SHORT).show();

        });


        //set SaveRecipe to button
        SaveRecipe = findViewById(R.id.SaveRecipe);

        SaveRecipe.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Saves recipe to your recipe list", LENGTH_SHORT).show();

        });


        //set Keyword input to the Text Input
        KeywordInput = findViewById(R.id.KeywordInput);


        /*
        //set SearchLocal to the checkbox
        SearchLocal = findViewById(R.id.SearchLocal);

        SearchLocal.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Turns on filter to use location", LENGTH_SHORT).show();

        });

        //set SearchCategory to checkbox
        SearchCategory = findViewById(R.id.SearchByCategory);

        SearchCategory.setOnClickListener(v -> {

            Toast.makeText(SearchActivity.this, "Turns on filter to use categories", LENGTH_SHORT).show();

        });

         */

    }
}