package flpoly.edu.mobiledeviceapps.homefrieduiprotoype;


import android.content.Context;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class IngredientAdapter extends RecyclerView.Adapter {

    public Context context;
    public ArrayList<Ingredient> ingredientsList;


    public IngredientAdapter(Context context, ArrayList<Ingredient> ingredientsList) {
        this.context = context;
        this.ingredientsList = ingredientsList;
    }


    @Override
    public int getItemCount() {
        if (ingredientsList != null) {
            return ingredientsList.size();
        } else {
            return 0;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = (View)LayoutInflater.from(parent.getContext()).inflate(R.layout.ingredient_view, parent, false);

        return new IngredientViewHolder(v);
    }

    //@Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }


    //@Override
    public void onBindViewHolder(@NonNull IngredientAdapter.IngredientViewHolder holder, int position) {
        Ingredient ingredient = ingredientsList.get(position);

        holder.name.setText(ingredient.ingredientName);
    }

    //Create viewholder class for ingredient recyclerview
    public static class IngredientViewHolder extends RecyclerView.ViewHolder {
        public View view;
        public TextView name;
        //public final CheckBox checkBox;

        public IngredientViewHolder(View ingredientView) {
            super(ingredientView);
            this.view = ingredientView;
            this.name = view.findViewById(R.id.CheckIngredient);
        }
    }
    
}
